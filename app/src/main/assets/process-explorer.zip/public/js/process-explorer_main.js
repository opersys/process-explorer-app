//####assets/js/model.cpuinfo.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var CpuInfo = Backbone.Model.extend({
    idAttribute: "no",

    set: function (n, options) {
        var o = this.attributes;
        n.totalDeltaTime =
            (n.utime + n.ntime + n.stime + n.itime + n.iowtime + n.irqtime + n.sirqtime) -
                (o.utime + o.ntime + o.stime + o.itime + o.iowtime + o.irqtime + o.sirqtime);

        n.userPct = ((n.utime + n.ntime) - (o.utime + o.ntime)) * 100  / n.totalDeltaTime;
        n.sysPct = (n.stime - n.stime) * 100 / n.totalDeltaTime;
        n.iowPct = (n.iowtime - o.iowtime) * 100 / n.totalDeltaTime;
        n.irqPct = ((n.irqtime + n.sirqtime) - (o.irqtime + o.sirqtime)) * 100 / n.totalDeltaTime;

        Backbone.Model.prototype.set.apply(this, arguments);
    }
});

var CpuInfoCollection = Backbone.Collection.extend({
    model: CpuInfo,
    url: "/sysinfo" // NOT USED
});

/* ******** */

//####assets/js/model.logcat.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var LogCat = Backbone.Model.extend({
    url: "/sysinfo", // NOT USED
    idAttribute: "no",

    // Parse the time logcat format.
    parse: function (input) {
        var ls, tag, spid, pid, msg, tim;

        if (!input || input.length == 0)
            return null;

        ls = input.line.split(":");
        sc = input.line.split(" ");

        // Prevent bad lines.
        if (!ls || ls.length == 1)
            return null;
        if (!sc || sc.length == 1)
            return null;

        tim = sc[1];
        tag = sc[2][0];
        ls.shift(); ls.shift();

        try {
            spid = /\(\s*([0-9]*)\s*\)/.exec(ls.shift());
            if (!spid) return null;
            pid = parseInt(spid[1]);
        } catch (e) {
            return null;
        }
        msg = ls.join(":").trim();

        return {
            no: input.no,
            tim: tim,
            tag: tag,
            pid: pid,
            msg: msg
        };
    }
});

var LogCatLines = Backbone.Collection.extend({
    model: LogCat,
    url: "/sysinfo", // NOT USED

    applyFilter: function (items) {
        var self = this;

        return _.filter(items, function (m) {
            var r = true;

            _.each(_.keys(self._filterData), function (k) {
                if (_.isArray(self._filterData[k]))
                    r = _.contains(self._filterData[k], m.get(k)) && r;
                else
                    r = (self._filterData[k] == m.get(k)) && r;
            });

            return r;
        });
    },

    addRaw: function (models) {
        var newItems = [], fnewItems;

        for (var i = 0; i < models.length; i++)
            newItems.push(new LogCat(models[i], {parse: true}));

        this._rawItems = this._rawItems.concat(newItems);
        fnewItems = this.applyFilter(newItems);
        this.add(fnewItems);
        this.trigger("append");
    },

    setFilterItem: function (filterItem, filterItemValue) {
        var fitems;

        this._filterData[filterItem] = filterItemValue;

        if (this.models)
            this.reset();

        fitems = this.applyFilter(this._k);

        if (fitems && fitems.length > 0) {
            this.add(fitems);
            this.trigger("append");
        }
    },

    clearFilterItem: function (filterItem) {
        delete this._filterData[filterItem];

        this.reset();

        this.add(this.applyFilter(this._rawItems));
        this.trigger("append");
    },

    getFilterItem: function (filterItem) {
        return this._filterData[filterItem];
    },

    getItem: function (i) {
        return this.at(i);
    },

    getLength: function () {
        return this.length;
    },

    clearAll: function () {
        this._rawItems = [];
        this.reset();
    },

    getRawLines: function () {
        return this._rawItems;
    },

    constructor: function () {
        var self = this, socket;

        Backbone.Collection.apply(this, arguments);

        socket = io.connect("http://" + window.location.host + "/logcat");
        self.no = 0;
        self._rows = [];
        self._filterData = {};
        self._rawItems = [];

        this.on("reset", function () {
            this.trigger("empty");
        });

        socket.on("logcat", function (lcData) {
            // Split into lines
            var lcLine, lcLines = lcData.split(/\n/);
            var lcModels = [];

            // Gather all the logcat lines so that they can be added
            // to the collection in a single bunch hopefully reducing
            // the processing time and lowering the number of events
            // raised.
            while (lcLine = lcLines.shift()) {
                if (lcLine != "") {
                    lcModels.push({
                        no: self.no++,
                        line: lcLine
                    });
                }
            }

            // Add all the models in a single call.
            self.addRaw(lcModels, {parse: true});
        });
    }
});


/* ******** */

//####assets/js/model.meminfo.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var MemInfo = Backbone.Model.extend({
    initialize: function () {
        this.set("memUsed");
    },

    set: function (n, v) {
        n.memUsed = this.get("memTotal") - this.get("memFree");
        Backbone.Model.prototype.set.apply(this, arguments);
    }
});


/* ******** */

//####assets/js/model.fs.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var File = Backbone.Model.extend({
    idAttribute: "path"
});

var FileSystem = Backbone.Collection.extend({
    model: File,
    url: "/fs",

    getItem: function (i) {
        return this.at(i);
    },

    getLength: function () {
        return this.length;
    }
});

/* ******** */

//####assets/js/model.options.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var OptionItem = Backbone.Model.extend({ });

var Options = Backbone.Collection.extend({
    localStorage: new Backbone.LocalStorage("Options"),
    model: OptionItem,

    // Initialize the option
    initOption: function (opt, val) {
        if (!this.findWhere({ opt: opt })) {
            var m = new OptionItem(
                { opt: opt, val: val}
            );

            this.add(m);
            m.save();
        }
    },

    toggleOption: function (opt) {
        var m;
        if ((m  = this.findWhere({ opt: opt }))) {
            var v = m.get("val");
            m.set("val", !v);
            m.save();
        }
    },

    getOption: function (opt) {
        return this.findWhere({ opt: opt });
    },

    getOptionValue: function (opt) {
        return this.getOption(opt).get("val");
    },

    setOptionValue: function (opt, nval) {
        var m;
        if ((m = this.findWhere({ opt: opt }))) {
            var v = m.get("val");
            m.set("val", nval);
            m.save();
        }
    },

    activate: function () {
        this.forEach(function (opt) {
            opt.trigger("change");
        });
    }
});


/* ******** */

//####assets/js/model.process.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var Process = Backbone.Model.extend({
    idAttribute: "pid",

    initialize: function () {
        // Properties specific to the view.
        this.attributes["ui-children"] = {};
        this.attributes["ui-indent"] = 0;
        this.attributes["ui-row"] = 0;
        this.attributes["ui-collapsed"] = false;
        this.attributes["ui-dead"] = false;

        // Calculated.
        this.attributes["cpuPct"] = 0;
        this.attributes["memPct"] = 0;
        //this.attributes["timestr"] = "00:00";
    },

    set: function (n, v) {
        var o = this.attributes;

        if (n == "utime" && o.utime)
            n.deltaUtime = v - o.utime;
        if (n.hasOwnProperty("utime") && o.utime)
            n.deltaUtime = n.utime - o.utime;

        if (n == "stime" && o.stime)
            n.deltaStime = v - o.stime;
        if (n.hasOwnProperty("stime") && o.stime)
            n.deltaStime = n.stime - o.stime;

        if (!n.deltaStime) n.deltaStime = 0;
        if (!n.deltaUtime) n.deltaUtime = 0;

        if (n.deltaUtime >= 0 && n.deltaStime >= 0)
            n.deltaTime = n.deltaUtime + n.deltaStime;

        // Hide the hours if the time is under 0, keeping the time compact.
        if (n.time) {
            var m = moment.utc(n.time, "X");
            if (m.hours() == 0)
                n.timestr = m.format("mm:ss");
            else
                n.timestr = m.format("hh[h]mm");
        }

        Backbone.Model.prototype.set.apply(this, arguments);
    },

    updateCpuPct: function (cpuPeriod) {
        if (this.get("deltaTime"))
            this.set("cpuPct", this.get("deltaTime") / cpuPeriod * 100);
        else
            this.set("cpuPct", 0);
    },

    updateMemPct: function (totalMem) {
        if (this.get("rss"))
            this.set("memPct", this.get("rss") / totalMem * 100);
        else
            this.set("memPct", 0);
    }
});

var ProcessCollection = Backbone.Collection.extend({
    model: Process,
    url: "/sysinfo", // NOT USED
    comparator: "ui-row",
    _rows: [],

    set: function () {
        var self = this;

        Backbone.Collection.prototype.set.apply(this, arguments);

        setTimeout(function () {
            self.reindex.call(self);
        }, 200);
    },

    _uirow_getItem: function (n) {
        return this._rows[n];
    },

    _uirow_getLength: function () {
        return this._rows.length;
    },

    _comparator_reindex: function () {},

    _uirow_reindex: function () {
        this._rows = [];

        // Iterate through the collection depth first to attribute row numbers
        var e, r = 0, iin = [this.get(0)];

        while ((e = iin.shift())) {
            if (!e.get("ui-collapsed"))
                iin = _.values(e.get("ui-children")).concat(iin);

            e.set("ui-row", r++);
            this._rows.push(e);
        }
    },

    sortPs: function (stype, isAsc) {
        if (stype == "ui-row") {
            this.reindex = this._uirow_reindex;
            this.getItem = this._uirow_getItem;
            this.getLength = this._uirow_getLength;
            this.treeView = true;
        }
        else {
            this.comparator = function (m) {
                return (isAsc ? 1 : -1) * m.get(stype);
            };
            this.sort();

            this.reindex = this._comparator_reindex;
            this.getItem = function (i) {
                return this.models[i];
            };
            this.getLength = function () {
                return this.models.length;
            };
            this.treeView = false;
         }
    },

    constructor: function () {
        Backbone.Collection.apply(this, arguments);

        this.reindex = this._uirow_reindex;
        this.getItem = this._uirow_getItem;
        this.getLength = this._uirow_getLength;
        this.treeView = true;

        this.on("change:ui-collapsed", function (m) {
            this.reindex();

            if (m && !m.get("ui-collapsed"))
                this.trigger("add");
            else
                this.trigger("remove");
        });
    }
});


/* ******** */

//####assets/js/view.chart.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Static color index.
var _colorIdx = 0;

var ChartView = Backbone.View.extend({

    _colors: [
        "#ff0000", "#00ffff", "#0000ff", "#0000a0", "#add8e6",
        "#800080", "#ffff00", "#00ff00", "#ff00ff", "#ffffff",
        "#c0c0c0", "#808080", "#000000", "#ffa500", "#a52a2a",
        "#800000", "#008000", "#808000"
    ],

    initialize: function (opts) {
        this._delay = opts.delay;
        this._max = opts.max;
        this._min = opts.min;
        this._field = opts.field;
        this._key = opts.key;
        this._model = opts.model;
        this._caption = opts.caption;
        this._width = opts.width;
        this._height = opts.height;
        this._series = {};

        this.$el.css("display", "inline-block");
        //this.$el.width(opts.width);
        //this.$el.height(opts.height);

        this.render();
    },

    setRange: function (range) {
        this._min = range.min;
        this._max = range.max;
    },

    getRange: function () {
        return {
            min: this._min,
            max: this._max
        }
    },

    resetDelay: function (newDelay) {
        var self = this;

        if (this._delay == newDelay)
            return;

        this._delay = newDelay;

        this._smoothie.stop();
        this._smoothie = new SmoothieChart({
            millisPerPixel: 90,
            grid: {
                verticalSections: 5
            },
            yRangeFunction: function (range) {
                return {min: self._min, max: self._max};
            }
        });
        this._smoothie.streamTo(this._canvas[0], this._delay);

        _.each(_.keys(this._series), function (skey) {
            self._series[skey].serie.data = [];
            self._smoothie.addTimeSeries(self._series[skey].serie, self._series[skey].options);
        });
    },

    render: function () {
        var self = this;

        this._wrapper = $("<div></div>")
            .addClass("chartView")
            .width(this._width)
            .height(this._height);

        if (this._caption)
            this._caption = $("<span>" + this._caption + "</span>");

        this._canvas = $("<canvas></canvas>");

        if (this._caption) {
            this.$el.append(this._wrapper
                .append(this._caption)
                .append(this._canvas));
            this._canvas
                .attr("height", this._wrapper.height() - this._caption.height())
                .attr("width", this._wrapper.width());
        } else {
            this.$el.append(this._wrapper
                .append(this._canvas));
            this._canvas
                .attr("height", this._wrapper.height())
                .attr("width", this._wrapper.width());
        }

        this._smoothie = new SmoothieChart({
            millisPerPixel: 90,
            grid: {
                verticalSections: 5
            },
            yRangeFunction: function (range) {
                return {min: self._min, max: self._max};
            }
        });

        this._smoothie.streamTo(this._canvas[0], this._delay);
    },

    addSerieData: function (skey, val) {
        if (this.hasSerie(skey))
            this._series[skey].serie.append(new Date().getTime(), val);
    },

    hasSerie: function (skey) {
        return _.has(this._series, skey);
    },

    start: function () {
        this._smoothie.start();
    },

    stop: function () {
        this._smoothie.stop();
    },

    serie: function (skey) {
        var serOpts = {};

        serOpts["lineWidth"] = 2;
        serOpts["strokeStyle"] = this._colors[_colorIdx++ % this._colors.length];

        this._series[skey] = {
            serie: new TimeSeries(),
            options: serOpts
        };

        this._smoothie.addTimeSeries(this._series[skey].serie, this._series[skey].options);
    }
});

/* ******** */

//####assets/js/view.logcat.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var LogCatView = Backbone.View.extend({

    _gridColumns: [
        { id: "tag", name: "T", field: "tag", minWidth: 20, maxWidth: 20 },
        { id: "tim", name: "time", field: "tim", midWidth: 60, maxWidth: 90 },
        { id: "pid", name: "PID", field: "pid", minWidth: 50, maxWidth: 50 },
        { id: "msg", name: "Message", field: "msg", minWidth: 300 }
    ],

    _gridOptions: {
        formatterFactory:{
            getFormatter: function (column) {
                return function(row,cell,value,col,data) {
                    return data.get(col.field);
                };
            }
        },

        enableColumnReorder: false,
        enableCellNavigation: true,
        forceFitColumns: true
    },

    clearColors: function () {
        this._grid.removeCellCssStyles("warnings");
        this._grid.removeCellCssStyles("errors");
    },

    applyColors: function () {
        var errorRows = [], warningRows = [];
        var errorCss = {
            "tag": "error", "tim": "error", "pid": "error", "msg": "error"
        };
        var warningCss = {
            "tag": "warning", "tim": "warning", "pid": "warning", "msg": "warning"
        };

        for (var i = 0; i < this._grid.getDataLength(); i++) {
            var row = this._grid.getDataItem(i);
            if (row.get("tag") == "E")
                errorRows[i] = errorCss;
            else if (row.get("tag") == "W")
                warningRows[i] = warningCss;
        }

        this._grid.setCellCssStyles("warnings", warningRows);
        this._grid.setCellCssStyles("errors", errorRows);
    },

    addTagFilter: function (tag) {
        var newfi, fi = this._logcat.getFilterItem("tag");

        if (_.isArray(fi))
            newfi = fi.concat([tag]);
        else
            newfi = [tag];

        this._logcat.setFilterItem("tag", newfi);
    },

    clearTagFilter: function (tag) {
        this._logcat.setFilterItem("tag", _.without(this._logcat.getFilterItem("tag"), tag));
    },

    filterByPid: function (pid) {
        if (this._options.getOptionValue("pidFilterMode")) {
            this._logcat.setFilterItem("pid", pid);

            // FIXME: Cheating on the model.
            $("#txtFiltered").text("Filtered for PID: " + pid);
        }
    },

    clearPidFilter: function () {
        this._logcat.clearFilterItem("pid");

        // FIXME: Cheating on the model
        $("#txtFiltered").text("");
    },

    scrollToEnd: function () {
        this._grid.scrollRowToTop(this._logcat.models[this._logcat.models.length - 1].get("no"));
    },

    autoResize: function () {
        this._grid.resizeCanvas();
        this._grid.autosizeColumns();
    },

    initialize: function (opts) {
        var self = this;

        self._ps = opts.ps;
        self._logcat = opts.logcat;
        self._options = opts.options;

        self._options.getOption("rowColorMode").on("change", function () {
            if (self._options.getOptionValue("rowColorMode"))
                self.applyColors();
            else
                self.clearColors();
        });

        self.render();
    },

    _readLogsTooltip: null,
    _hasReadLogHeuristicDone: false,

    /**
     * This is meant as a best-effort heuristic to detect if the application was granted the
     * READ_LOGS permission, which needs to be done manually on Android versions after 4.4.
     */
    readLogsHeuristicCheck: function () {
        var self = this;
        var ss;

        if (!self._readLogsTooltip) {
            var chkId = _.uniqueId("opentip");

            self._readLogsTooltip = new Opentip(this.$el, {
                title: "Not much to see there isn't it?",
                target: this.$el,
                style: "warnPopup",
                targetJoint: "top left",
                tipJoint: "bottom left",
                showOn: null
            });
            self._readLogsTooltip.setContent(
                "<p>Unless Process Explorer has the right to read logs, per-process " +
                " logs will appear blank.</p>" +
                "<p>Give Process Explorer the permission to read the logcat by running the following " +
                "command your computer. You\'ll then need to click on \"Quit the application\" in the " +
                "Process Explorer app on the device and restart the app and the service for the change to " +
                "take effect:</p> " +
                "<pre>$ adb shell pm grant com.opersys.processexplorer android.permission.READ_LOGS</pre>" +
                '<input id="' + chkId + '" type="checkbox" />' +
                '<label for="' + chkId + '">Don\'t show this message again</label>');
        }

        if (self._hasReadLogHeuristicDone)
            return;

        // Get the PID of the system_server process.
        ss = self._ps.findWhere({name: "system_server"});

        // Not finding the system_server would be quite an odd situation but it could happen
        // (I guess). So log it out and presume the user knows what it is doing.
        if (!ss) {
            console.log("Could not find system_server PID");
        } else if (!_.find(self._logcat.getRawLines(), function (lc) {
                return lc.get("pid") == ss.get("pid");
            }))
        {
            self._readLogsTooltip.show();
            $(document.getElementById(chkId)).on("click", function () {
                self._hasReadLogHeuristicDone = true;
                self._readLogsTooltip.hide();
            });
        }
    },

    render: function () {
        var self = this;

        this._grid = new Slick.Grid(this.$el, this._logcat, this._gridColumns, this._gridOptions);

        this._logcat.on("add", $.debounce(250,
            function (m) {
                self._grid.scrollRowToTop(m.get("no"));
            }
        ));

        this._logcat.on("append", function () {
            self._grid.updateRowCount();
            self._grid.render();

            // Options
            if (self._options.getOptionValue("rowColorMode"))
                self.applyColors();
        });

        this._logcat.on("remove", function () {
            self._grid.updateRowCount();
            self._grid.render();
        });

        this._logcat.on("empty", function () {
            self._grid.updateRowCount();
            self._grid.render();
        });

        // Options
        if (this._options.getOptionValue("rowColorMode"))
            this.applyColors();

        this._grid.setSelectionModel(new Slick.RowSelectionModel());

        this._grid.resizeCanvas();
    }
});

/* ******** */

//####assets/js/view.process.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var ProcessView = Backbone.View.extend({

    _nameFormatter: function (row, cell, value, columnDef, proc) {
        var pkg, v, isPkg;

        if (proc.get("cmdline") && proc.get("cmdline") != "")
            pkg = proc.get("cmdline").split(" ")[0];

        isPkg = pkg && pkg.indexOf(".") != -1 && pkg.indexOf("/")  == -1;

        if (isPkg)
            v = pkg;
        else
            v = proc.get(columnDef.field);

        if (!this._ps.treeView)
            return this._grid.getOptions().defaultFormatter(row, cell, v, columnDef, proc);

        var spacer = "<span style='display: inline-block; height: 1px; width: "
            + (15 * proc.get("ui-indent") - 1) + "px'></span>";

        var img = "<span style='display: inline-block; height: 15px; width: 15px; margin-right: 3px;"
            + "background-size: 15px 15px;";

        if (isPkg)
            img += "background-image: url(\"http://" + window.location.host + "/icon/" + pkg + "\");";

        img += "'></span>";

        if (_.size(proc.get("ui-children")) > 0) {
            if (proc.get("ui-collapsed"))
                return spacer + " <span class='toggle expand'></span>&nbsp;" + img + v;
            else
                return spacer + " <span class='toggle collapse'></span>&nbsp;" + img + v;
        } else
            return spacer + " <span class='toggle'></span>&nbsp;" + img + v;
    },

    _memoryFormatter: function (row, cell, value, columnDef, proc) {
        return Humanize.filesizeformat(proc.get(columnDef.field));
    },

    _percentFormatter: function (row, cell, value, columnDef, proc) {
        return proc.get(columnDef.field).toFixed(1) + "%";
    },

    _timeFormatter: function (row, cell, value, columnDef, proc) {
        var v = proc.get(columnDef.field);

        if (!v || v == 0) return "00:00";

        var m = moment.utc(v, "X");
        if (m.hours() == 0)
            return m.format("mm:ss");
        else
            return m.format("hh[h]mm");
    },

    _gridColumns: [
        { id: "name", name: "Name", field: "name" },
        { id: "pid", name: "PID", field: "pid", minWidth: 30, maxWidth: 50,
            toolTip: "Process Id" },
        { id: "state", name: "S", field: "state", minWidth: 15, maxWidth: 20,
            toolTip: "Status\nD = uninterruptible sleep\nR = running\nS = sleeping\nT = traced or stopped\nZ = zombie\n" },
        { id: "prio", name: "PRI", field: "prio", minWidth: 20, maxWidth: 30,
            toolTip: "Priority" },
        { id: "cpuPct", name: "%CPU", field: "cpuPct", minWidth: 40, maxWidth: 60, sortable: true,
            toolTip: "CPU Usage\nThe CPU time divided by the time the process has been running." },
        { id: "memPct", name: "%Mem", field: "memPct", minWidth: 40, maxWidth: 60, sortable: true,
            toolTip: "Memory Usage\nThe ratio of the RSS to the total memory." },
        { id: "vss", name: "VSS", field: "vss", minWidth: 60, maxWidth: 80, sortable: true,
            toolTip: "Virtual Set Size\nThe total memory size a process might use." },
        { id: "rss", name: "RSS", field: "rss", minWidth: 60, maxWidth: 80, sortable: true,
            toolTip: "Resident Set Size\nThe non-swapped physical memory used." },
        { id: "shm", name: "SHM", field: "shm", minwidth: 60, maxWidth: 80, sortable: true,
            toolTip: "Shared Memory Size\nThe memory that could be potentially shared with other processes." },
        { id: "time", name: "Time", field: "time", minWidth: 60, maxWidth: 80, sortable: true ,
            toolTip: "CPU Time"},
        { id: "cmdline", name: "Command line", field: "cmdline", minWidth: 80 }
    ],

    _gridOptions: {
        formatterFactory:{
            getFormatter: function (column) {
                return function(row,cell,value,col,data) {
                    return data.get(col.field);
                };
            }
        },

        enableColumnReorder: false,
        enableCellNavigation: true,
        forceFitColumns: true
    },

    applyColors: function () {
        var deadRows = {};
        var deadCss = {
            "name": "dead", "pid": "dead", "state": "dead", "prio": "dead", "cpuPct": "dead",
            "memPct": "dead", "vss": "dead", "rss": "dead", "shm": "dead", "time": "dead",
            "cmdline": "dead"
        };

        for (var i = 0; i < this._grid.getDataLength(); i++) {
            var row = this._grid.getDataItem(i);
            if (row.get("ui-dead"))
                deadRows[i] = deadCss;
        }

        this._grid.setCellCssStyles("dead", deadRows);
    },

    _updateProcess: function (fname, proc, v, opts) {
        var colIdx, rowIdx, self = this;

        colIdx = this._grid.getColumnIndex(fname);
        rowIdx = proc.get("ui-row");

        setTimeout(function () {
            self._grid.flashCell(rowIdx, colIdx, 750);
        }, 100);
    },

    _onGridClick: function (e, args) {
        var proc = this._grid.getDataItem(args.row);

        if ($(e.target).hasClass("toggle")) {
            if (!proc.get("ui-collapsed"))
                proc.set({"ui-collapsed": true});
            else
                proc.set({"ui-collapsed": false});
        }
    },

    _onGridSelectedRowsChange: function (e, args) {
        var sel = this._grid.getActiveCell();

        if (sel)
            this.trigger("onProcessSelected", this._grid.getDataItem(sel.row));
    },

    _sendSignal: function (proc, signal) {
        var name = proc.get("name");
        var pid = proc.get("pid");

        console.log("_sendSignal(" + pid + "," + signal + ")");

        $.ajax({
            url: "/os/kill",
            type: "post",
            data: {pid: pid, signal: signal},
        })
        .done(function(data) {
            if (data.status == "success") {
                // Successfully sent the requested signal to the pid
                $.notify("Sent " + signal + " to " + name + " (" + pid + ")", "success");
            }
            else if (data.status == "error") {
                // An error occured
                error_msg = data.error + " : ";

                switch (data.error) {
                    case "EPERM":
                        error_msg += "operation not permitted";
                        break;
                    case "ESRCH":
                        error_msg += "no such process";
                        break;
                    default:
                        error_msg += "unknown error"
                }

                $.notify("Error sending " + signal + " to " + name + " (" + pid + "):\n" + error_msg, "error");
            }
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
            // The AJAX query failed somehow
            $.notify("Error sending " + signal + " to " + name + " (" + pid + "):\n" + errorThrown, "error");
        });

        return true;
    },

    _displaySignalForm: function(proc) {
        var self = this;

        var signal_list = [
            {id: 'SIGHUP', text: 'SIGHUP (1) - Hangup detected on controlling terminal or death of controlling process'},
            {id: 'SIGINT', text: 'SIGINT (2) - Interrupt from keyboard'},
            {id: 'SIGQUIT', text: 'SIGQUIT (3) - Quit from keyboard'},
            {id: 'SIGILL', text: 'SIGILL (4) - Illegal Instruction'},
            {id: 'SIGABRT', text: 'SIGABRT (6) - Abort signal from abort(3)'},
            {id: 'SIGFPE', text: 'SIGFPE (8) - Floating point exception'},
            {id: 'SIGKILL', text: 'SIGKILL (9) - Kill signal'},
            {id: 'SIGSEGV', text: 'SIGSEGV (11) - Invalid memory reference'},
            {id: 'SIGPIPE', text: 'SIGPIPE (13) - Broken pipe: write to pipe with no readers'},
            {id: 'SIGALRM', text: 'SIGALRM (14) - Timer signal from alarm(2)'},
            {id: 'SIGTERM', text: 'SIGTERM (15) - Termination signal'},
            {id: 'SIGUSR1', text: 'SIGUSR1 (10) - User-defined signal 1'},
            {id: 'SIGUSR2', text: 'SIGUSR2 (12) - User-defined signal 2'},
            {id: 'SIGHLD', text: 'SIGHLD (17) - Child stopped or terminated'},
            {id: 'SIGCONT', text: 'SIGCONT (18) - Continue if stopped'},
            {id: 'SIGSTOP', text: 'SIGSTOP (19) - Stop process'},
            {id: 'SIGSTP', text: 'SIGTSTP (20) - Stop typed at terminal'},
            {id: 'SIGTTIN', text: 'SIGTTIN (21) - Terminal input for background process'},
            {id: 'SIGTTOU', text: 'SIGTTOU (22) - Terminal output for background process'}
        ];

        if (!w2ui.sendSignalForm) {
            $().w2form({
                name: 'sendSignalForm',
                url: '#',
                fields: [
                    { field: 'process', type: 'text', required: true, html: { caption: 'Process', attr: 'style="width: 300px" readonly'} },
                    { field: 'signal',
                        type: 'list',
                        options: {match: 'contains', items: signal_list },
                        required: true,
                        html: { caption: 'Signal', attr: 'style="width: 300px"' } },
                ],
                actions: {
                    "cancel": function () { w2popup.close(); },
                    "send": function () {
                        // validate() returns an array of errors
                        if (this.validate().length == 0) {
                            self._sendSignal(proc, this.record.signal.id);
                            w2popup.close();
                        }
                    },
                }
            });

        }

        w2ui.sendSignalForm.record = {
            process    : proc.get("name") + " (" + proc.get("pid") + ")",
            signal     : '',
        };

        w2ui.sendSignalForm.refresh();

        $().w2popup('open', {
            title   : 'Send a signal...',
            body    : '<div id="form" style="width: 100%; height: 100%;"></div>',
            style   : 'padding: 15px 0px 0px 0px',
            width   : 500,
            height  : 300,
            showMax : true,
            onToggle: function (event) {
                $(w2ui.sendSignalForm.box).hide();
                event.onComplete = function () {
                    $(w2ui.sendSignalForm.box).show();
                    w2ui.sendSignalForm.resize();
                }
            },
            onOpen: function (event) {
                event.onComplete = function () {
                    $('#w2ui-popup #form').w2render('sendSignalForm');
                }
            }
        });
    },

    _onGridContextMenu: function (e, args) {
        var self = this;

        // Prevent the default context menu...
        e.preventDefault();

        // SlickGrid doesn't pass the cell in the 'onContextMenu' event arguments
        // unlike the onClick event.
        var cell = this._grid.getCellFromEvent(e);
        var proc = this._grid.getDataItem(cell.row);

        // Highlight the newly right clicked row
        this._grid.setActiveCell(cell.row, cell.cell);

        // ... and display our own context menu
        $(e.target).w2menu({
            items: [
                {
                    id: 'signal-sigterm', text: 'Terminate process (SIGTERM)',
                    icon: "icon-remove",
                    onSelect: function (e) { return self._sendSignal(proc, "SIGTERM"); },
                },
                {
                    id: 'signal-sigkill', text: 'Kill process (SIGKILL)',
                    icon: "icon-ban-circle",
                    onSelect: function(e) { return self._sendSignal(proc, "SIGKILL"); },
                },
                {
                    id: 'signall-sighup', text: 'Restart process (SIGHUP)',
                    icon: "icon-refresh",
                    onSelect: function(e) { return self._sendSignal(proc, "SIGHUP"); },
                },
                { id: 'separator', text: '--'},
                {
                    id: 'signal-sigstop', text: 'Pause process (SIGSTOP)',
                    icon: "icon-pause",
                    onSelect: function(e) { return self._sendSignal(proc, "SIGSTOP"); },
                },
                {
                    id: 'signal-sigcont',
                    text: 'Continue process (SIGCONT)',
                    icon: "icon-play",
                    onSelect: function(e) { return self._sendSignal(proc, "SIGCONT"); },
                },
                { id: 'separator', text: '--'},
                {
                    id: 'signal-send', text: 'Send signal',
                    onSelect: function(e) { return self._displaySignalForm(proc); },
                },
                { id: 'separator', text: '--' },
                {
                    id: 'details', text: 'Details', icon: "icon-info",
                    onSelect: function(e) {
                        self.trigger("onContextMenuDetailsClick");
                    },
                },
            ],
            onSelect: function (e) {
                if ('onSelect' in e.item && typeof e.item.onSelect === 'function') {
                    e.item.onSelect(e)
                }
            }
        });
    },

    getSelectedProcess: function () {
        var sel = this._grid.getActiveCell();
        if (sel)
            return this._grid.getDataItem(sel.row);
        else
            return null;
    },

    _onGridSort: function (e, args) {
        var colText, colIdx;

        this._ps.sortPs(args.sortCol.field, args.sortAsc);
        this._grid.invalidate();
        this._grid.render();

        colIdx = this._grid.getColumnIndex(args.sortCol.field);
        colText = this._grid.getColumns()[colIdx].name;
        this.trigger("sort", args.sortCol.field, colText);
    },

    treeSort: function () {
        this._ps.sortPs("ui-row");
        this._grid.invalidate();
        this._grid.render();
    },

    autoResize: function () {
        this._grid.resizeCanvas();
        this._grid.autosizeColumns();
    },

    initialize: function (opts) {
        this._ps = opts.ps;
        this._options = opts.options;
        this._toggleProcessDetails = opts.toggleProcessDetails;

        this.render();
    },

    render: function () {
        var self = this;

        // Create and initialize the grid as per:
        // https://github.com/mleibman/SlickGrid/blob/gh-pages/examples/example-explicit-initialization.html
        this._grid = new Slick.Grid(this.$el, this._ps, this._gridColumns, this._gridOptions);

        // Initialize the column formatters and call the formatters
        // in the context of the view.

        this._gridColumns[this._grid.getColumnIndex("name")].formatter = function () {
            return self._nameFormatter.apply(self, arguments);
        };

        this._gridColumns[this._grid.getColumnIndex("cpuPct")].formatter = function () {
            return self._percentFormatter.apply(self, arguments);
        };

        this._gridColumns[this._grid.getColumnIndex("memPct")].formatter = function () {
            return self._percentFormatter.apply(self, arguments);
        };

        this._gridColumns[this._grid.getColumnIndex("rss")].formatter = function () {
            return self._memoryFormatter.apply(self, arguments);
        };

        this._gridColumns[this._grid.getColumnIndex("vss")].formatter = function () {
            return self._memoryFormatter.apply(self, arguments);
        };

        this._gridColumns[this._grid.getColumnIndex("shm")].formatter = function () {
            return self._memoryFormatter.apply(self, arguments);
        };

        this._gridColumns[this._grid.getColumnIndex("time")].formatter = function () {
            return self._timeFormatter.apply(self, arguments);
        };

        this._grid.onClick.subscribe(function (e, args) {
            self._onGridClick.apply(self, [e, args]);
        });
        this._grid.onSort.subscribe(function (e, args) {
            self._onGridSort.apply(self, [e, args]);
        });
        this._grid.onSelectedRowsChanged.subscribe(function (e, args) {
            self._onGridSelectedRowsChange(self, [e, args]);
        });
        this._grid.onContextMenu.subscribe(function (e, args) {
            self._onGridContextMenu.apply(self, [e, args]);
        });

        this._ps.on("change:cpuPct", function (m, v, opts) {
            self._updateProcess("cpuPct", m, v, opts);
        });
        this._ps.on("change:memPct", function (m, v, opts) {
            self._updateProcess("memPct", m, v, opts);
        });
        this._ps.on("change:vss", function (m, v, opts) {
            self._updateProcess("vss", m, v, opts)
        });
        this._ps.on("change:rss", function (m, v, opts) {
            self._updateProcess("rss", m, v, opts)
        });

        this._ps.on("add", function () {
            this.reindex();

            self._grid.invalidate();
            self._grid.updateRowCount();

            self._grid.render();
            self.applyColors();
        });

        this._ps.on("remove", function (rmModel) {
            this.reindex();

            self._grid.invalidate();
            self._grid.updateRowCount();

            self._grid.render();
            self.applyColors();
        });

        this._ps.on("change", function (m) {
            self._grid.invalidateRow(m.get("ui-row"));

            self._grid.render();
            self.applyColors();
        });

        this._grid.setSelectionModel(new Slick.RowSelectionModel());

        this._grid.resizeCanvas();
    }
});



/* ******** */

//####assets/js/view.process.details.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var ProcessDetailsView = Backbone.View.extend({

    _expand_width: $(window).width() * 0.35,

    handleEnvironment: function(element, data) {
        var self = this;

        // HTML layout
        var environment_content = document.createElement('div');
        var table_element = document.createElement('div');

        environment_content.appendChild(table_element)

        element.html(environment_content);

        // HTML content
        var data_table = new google.visualization.DataTable();
        var data_array = [];

        for (var name in data.variables) {
            if (data.variables.hasOwnProperty(name)) {
                data_array.push([name, data.variables[name]]);
            }
        }

        data_table.addColumn("string", "Name");
        data_table.addColumn("string", "Value");
        data_table.addRows(data_array);

        var table_chart = new google.visualization.Table(table_element);
        table_chart.draw(data_table);
    },

    handleMemoryMaps: function(element, data) {
        var self = this;

        // HTML layout
        var memorymaps_content = document.createElement('div');
        var table_element = document.createElement('div');

        memorymaps_content.appendChild(table_element);

        element.html(memorymaps_content);

        // HTML content
        var data_table = new google.visualization.DataTable();
        var data_array = [];

        data.maps.forEach(function(map) {
            data_array.push([map.address, map.permissions, map.pathname]);
        });

        data_table.addColumn("string", "Address");
        data_table.addColumn("string", "Permissions");
        data_table.addColumn("string", "Path");
        data_table.addRows(data_array);

        var table_chart = new google.visualization.Table(table_element);
        table_chart.draw(data_table);
    },

    handleMemoryUsage: function(element, data) {
        var self = this;

        // HTML layout
        var memory_usage_content = document.createElement('div');
        var chart_element = document.createElement('div');
        var table_element = document.createElement('div');

        memory_usage_content.appendChild(chart_element);
        memory_usage_content.appendChild(table_element);

        element.html(memory_usage_content);

        // HTML content
        var data_table = new google.visualization.DataTable();
        var data_array = [];
        var data_max = 0; // max value, to limit the upper bound of the graph

        for (var heap_type in data.memusage) {
            if (data.memusage.hasOwnProperty(heap_type)) {
                var heap_stats = data.memusage[heap_type];
                var priv = (heap_stats["private_clean"] + heap_stats["private_dirty"]) * 1024;
                var shared = (heap_stats["shared_clean"] + heap_stats["shared_dirty"]) * 1024;
                var pss = heap_stats["pss"] * 1024;

                data_array.push([heap_type, priv, shared, pss]);

                data_max = Math.max(data_max, priv, shared, pss);
            }
        }

        data_table.addColumn("string", "Heap");
        data_table.addColumn("number", "Private");
        data_table.addColumn("number", "Shared");
        data_table.addColumn("number", "PSS");
        data_table.addRows(data_array);

        var options = {
            title: 'Memory usage',
            isStacked: true,
            height: 500,
            vAxis: {
                title: 'Bytes',
            },
            vAxis: {
                viewWindow: {
                    max: data_max,
                }
            },
            series: {
                2: {
                    targetAxisIndex: 1
                },
                3: {
                    targetAxisIndex: 1
                },
            },
        };

        var chart = new google.charts.Bar(chart_element);
        chart.draw(data_table, google.charts.Bar.convertOptions(options));

        var table_chart = new google.visualization.Table(table_element);
        table_chart.draw(data_table);
    },

    handleFiles: function(element, data) {
        var self = this;

        // HTML layout
        var files_content = document.createElement('div');
        var table_element = document.createElement('div');

        files_content.appendChild(table_element);

        element.html(files_content);

        // HTML content
        var data_table = new google.visualization.DataTable();
        var data_array = [];

        data.files.forEach(function(file){
            data_array.push([parseInt(file.fd), file.path]);
        });

        data_table.addColumn("number", "File Descriptor");
        data_table.addColumn("string", "Path");
        data_table.addRows(data_array);

        var table_chart = new google.visualization.Table(table_element);
        table_chart.draw(data_table);
    },

    handleNetworkConnections: function(element, data) {
        var self = this;

        // HTML layout
        var networkconnections_content = document.createElement('div');
        var ip4_title = document.createElement('h3');
        ip4_title.textContent = "inet";
        var ip4_table_element = document.createElement('div');
        var ip6_title = document.createElement('h3');
        ip6_title.textContent = "inet6";
        var ip6_table_element = document.createElement('div');

        networkconnections_content.appendChild(ip4_title);
        networkconnections_content.appendChild(ip4_table_element);
        networkconnections_content.appendChild(ip6_title);
        networkconnections_content.appendChild(ip6_table_element);

        element.html(networkconnections_content);

        // HTML content
        var ip4_data_table = new google.visualization.DataTable();
        var ip6_data_table = new google.visualization.DataTable();
        var ip4_data_array = [];
        var ip6_data_array = [];

        data.networkconnections.forEach(function(conn){
            if (conn.type == "tcp6" || conn.type == "udp6" ) {
                ip6_data_array.push([conn.src_ip + ":" + conn.src_port, conn.dst_ip + ":" + conn.dst_port, conn.type, conn.status]);
            }
            else {
                ip4_data_array.push([conn.src_ip + ":" + conn.src_port, conn.dst_ip + ":" + conn.dst_port, conn.type, conn.status]);
            }
        });

        ip4_data_table.addColumn("string", "Source");
        ip4_data_table.addColumn("string", "Destination");
        ip4_data_table.addColumn("string", "Protocol");
        ip4_data_table.addColumn("string", "Status");

        ip6_data_table.addColumn("string", "Source");
        ip6_data_table.addColumn("string", "Destination");
        ip6_data_table.addColumn("string", "Protocol");
        ip6_data_table.addColumn("string", "Status");

        ip4_data_table.addRows(ip4_data_array);
        ip6_data_table.addRows(ip6_data_array);

        var ip4_table_chart = new google.visualization.Table(ip4_table_element);
        ip4_table_chart.draw(ip4_data_table);

        var ip6_table_chart = new google.visualization.Table(ip6_table_element);
        ip6_table_chart.draw(ip6_data_table);
    },

    _hasWarnedAboutRunningAsRoot: false,

    _rootTooltip: null,

    fetchProcessDetails: function(url, handler) {
        var self = this, chkId = _.uniqueId("opentip");

        if (!self._rootTooltip) {
            self._rootTooltip = new Opentip(self.$el, {
                title: "Having access error?",
                target: self.$el,
                style: "warnPopup",
                targetJoint: "top left",
                tipJoint: "top right",
                showOn: null
            });
            self._rootTooltip.setContent(
                "<p>Unless Process Explorer runs as root, you won't be able to view per-process " +
                "detailed information. If you have one of the 'su' apps installed, enable the " +
                "'Run as root' option above before starting the service.</p>" +
                "<p>If you're using the AOSP emulator run the following on your computer and don't " +
                "make use of the 'Start the service' button.</p>" +
                "<pre>$ adb shell 'cd /data/user/0/com.opersys.processexplorer/files &amp;&amp; ./node ./app.js'</pre>" +
                '<input id="' + chkId + '" type="checkbox" />' +
                '<label for="' + chkId + '">Don\'t show this message again</label>'
            );
        }

        $.ajax({
            url: url,
        }).done(function(data) {
            if (data.status == "success") {
                handler.apply(self, [$('#processdetails_content'), data]);
            }
            else {
                error_msg = "Unable to load process details for " +
                    self._process.get("name") + " (" + self._process.get("pid") + ")\n";

                switch (data.error) {
                    case "EACCES":
                    {
                        error_msg += "You don't have the permission. (permission denied)";

                        if (!self._hasWarnedAboutRunningAsRoot)
                        {
                            self._rootTooltip.show();

                            $(document.getElementById(chkId)).on("click", function () {
                                self._rootTooltip.hide();
                                self._hasWarnedAboutRunningAsRoot = true;
                            });
                        }
                        else self._rootTooltip.hide();
                    }
                        break;
                    case "ENOENT":
                        error_msg += "The process doesn't seem to exist anymore. (no such file or directory)";
                        break;
                    default:
                        error_msg += ":( (" + data.error + ")";
                }

                $.notify(error_msg, "error");
            }
        });
    },

    initialize: function (opts) {
        var self = this;

        this._process = null;
        self._options = opts.options;

        var pstyle = 'background-color: #F5F6F7; border: 1px solid #dfdfdf; padding: 5px;';

        // Google Chart
        google.load("visualization", "1.1", {packages:["corechart", "bar", "table"], callback: function() {
            }
        });

        // Create the layout
        self.$el.w2layout({
            name: 'processdetails_layout',
            panels: [
                { type: 'main',
                    title: '<div id="processdetails_title"></div>',
                    content: '<div id="processdetails_content"></div><div id="processdetails_label">Process Details</div>',
                    tabs: {
                        name: 'processDetailsTabs',
                        active: 'files',
                        tabs: [
                            { id: 'files', caption: 'Files', closable: false },
                            { id: 'memory', caption: 'Memory', closable: false },
                            { id: 'environment', caption: 'Environment', closable: false },
                            { id: 'memory_usage', caption: 'Memory usage', closable: false },
                            { id: 'network_connections', caption: 'Network', closable: false },
                        ],
                        onClick: function (event) {
                            if (event.target == "environment") {
                                self.fetchProcessDetails.apply(self,
                                        ["/process/environ?pid=" + self._process.get("pid"), self.handleEnvironment]);
                            }
                            else if (event.target == "memory") {
                                self.fetchProcessDetails.apply(self,
                                        ["/process/maps?pid=" + self._process.get("pid"), self.handleMemoryMaps]);
                            }
                            else if (event.target == "files") {
                                self.fetchProcessDetails.apply(self,
                                        ["/process/files?pid=" + self._process.get("pid"), self.handleFiles]);
                            }
                            else if (event.target == "memory_usage") {
                                self.fetchProcessDetails.apply(self,
                                        ["/process/memusage?pid=" + self._process.get("pid"), self.handleMemoryUsage]);
                            }
                            else if (event.target == "network_connections") {
                                self.fetchProcessDetails.apply(self,
                                        ["/process/networkconnections?pid=" + self._process.get("pid"), self.handleNetworkConnections]);
                            }
                        }
                    }
                },
            ],
            onResize: function(ev) {
                ev.onComplete = function() {
                    // FIXME - bv @ 2014-12-19
                    // Fairly inefficient way to refresh the charts so that
                    // they will use 100% of the new width.
                    if (w2ui['processdetails_layout_main_tabs'].active == 'memory_usage') {
                        w2ui['processdetails_layout_main_tabs'].click('memory_usage');
                    }
                };
            },
        });

        $("#processdetails_title").w2toolbar({
                name: 'processdetails_collapse',
                items: [
                    { type: 'button', id: 'collapse', icon: 'icon-chevron-left' },
                    { type: "html", html: "<span style='margin-left: 1em'>Process details</span>" },
                ],
                onClick: function(event) {
                    self.toggle.apply(self);
                },
            });

        // The panel is initially toggled
        $(self.$el).addClass("collapsed");
        $("#processdetails_content").css("display", "none");
        $("#processdetails_label").css("display", "block");
        w2ui["processdetails_layout"].hideTabs("main");
    },

    toggle: function() {
        var self = this;

        if ($(self.$el).hasClass("collapsed")) {
            w2ui["processdetails_collapse"].get("collapse").icon = "icon-chevron-right";
            w2ui["ps_layout"].sizeTo("right", self._expand_width);

            // Show the body of the layout.
            $("#processdetails_content").css("display", "block");
            $("#processdetails_label").css("display", "none");
            w2ui["processdetails_layout"].showTabs("main");
        }
        else {
            w2ui["processdetails_collapse"].get("collapse").icon = "icon-chevron-left";
            self._expand_width = w2ui["ps_layout"].get("right").width;
            w2ui["ps_layout"].sizeTo("right", 40);

            // Hide the body of the layout.
            $("#processdetails_content").css("display", "none");
            $("#processdetails_label").css("display", "block");
            w2ui["processdetails_layout"].hideTabs("main");
        }

        w2ui["processdetails_collapse"].refresh();
        $(self.$el).toggleClass("collapsed");

        return;
    },

    refresh: function() {
        $('#processdetails_content').html("");
        w2ui['processdetails_layout_main_tabs'].click(w2ui['processdetails_layout_main_tabs'].active);
    },

    setProcess: function(process) {
        this._process = process;
    },
});


/* ******** */

//####assets/js/view.tab.ps.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var ProcessTab = Backbone.View.extend({

    toggleTagFilter: function (optName, tagVal) {
        var self = this;

        return function () {
            var v = self.options.getOptionValue(optName);

            if (v)
                self.logCatView.addTagFilter(tagVal);
            else
                self.logCatView.clearTagFilter(tagVal);
        };
    },

    setButton: function (toolbar, btnId, value) {
        _.each(toolbar.items, function (b) {
            if (b.id == btnId) {
                _.each(_.keys(value), function (k) {
                    b[k] = value[k];
                });
            }
        });
    },

    graphUpdate: function (psView) {
        var self = psView;

        $.ajax("/cpuinfo").done(function (cpuinfo) {
            self.cpuInfo.set(cpuinfo.cpus);

            // Initialize and update the CPU graph
            self.cpuInfo.each(function (ci) {
                if (!self.cpuChart.hasSerie(ci.get("no")))
                    self.cpuChart.serie(ci.get("no"), "userPct", ci);

                self.cpuChart.addSerieData(ci.get("no"), ci.get("userPct"));
            });
        });

        $.ajax("/meminfo").done(function (meminfo) {
            self.memInfo.set(meminfo);

            if (!self.memChart.hasSerie("memUsed"))
                self.memChart.serie("memUsed");

            // Update the memory chart range if needed.
            if (self.memChart.getRange().max != self.memInfo.get("memTotal"))
                self.memChart.setRange({min: 0, max: self.memInfo.get("memTotal")});

            // Update the memory graphs.
            self.memChart.addSerieData("memUsed", self.memInfo.get("memUsed"));
        });
    },

    globalProcessUpdate: function (psView) {
        var self = psView;

        $.ajax("/sysinfo").done(function (sysinfo) {
            var totalDeltaTime;

            self.globalCpu.set(sysinfo.cpuinfo.global);
            self.cpuInfo.set(sysinfo.cpuinfo.cpus);
            self.memInfo.set(sysinfo.meminfo);

            self.ps.set(uncompress(sysinfo.ps));

            self.ps.each(function (proc) {
                var newChildren = {};

                proc.updateCpuPct(self.globalCpu.get("totalDeltaTime") / self.globalCpu.get("ncpu"));
                proc.updateMemPct(self.memInfo.get("memTotal"));

                _.each(_.keys(proc.get("ui-children")), function (cprocPid) {
                    if (!self.ps.get(cprocPid)) {
                        proc.get("ui-children")[cprocPid].set("ui-dead", true);
                        newChildren[cprocPid] = proc.get("ui-children")[cprocPid];
                    } else
                        newChildren[cprocPid] = self.ps.get(cprocPid);
                });
                proc.set("ui-children", newChildren);
            });

            // Calculate the process tree
            self.ps.each(function (e) {
                if (e.get("pid") != 0 && e.get("ppid") != undefined) {
                    var ppsItem = self.ps.get(e.get("ppid"));
                    var ppsItemCh = ppsItem.get("ui-children");

                    // Add the new children to the parent.
                    ppsItemCh[e.get("pid")] = e;
                    ppsItem.set({"ui-children": ppsItemCh});

                    // Set the indent and the order of the current process in the
                    // tree view.
                    e.set({
                        "ui-indent": ppsItem.get("ui-indent") +  1,
                        "ui-parent": ppsItem
                    });
                }
            });
        });
    },

    initialize: function (opt) {
        var self = this;

        self.$el = opt.target;

        // ProcessCollection object, collection of all process.
        self.ps = new ProcessCollection();

        // Global CPU Info
        self.globalCpu = new CpuInfo();

        // Individual CPU info
        self.cpuInfo = new CpuInfoCollection();

        // Logcat
        self.logCatLines = new LogCatLines();

        // Memory info
        self.memInfo = new MemInfo();

        // Logcat
        //self.logcat = new LogCat();

        // Options model
        self.options = opt.options;

        self.options.getOption("filterError").on("change", self.toggleTagFilter("filterError", "E"));
        self.options.getOption("filterWarning").on("change", self.toggleTagFilter("filterWarning", "W"));
        self.options.getOption("filterInfo").on("change", self.toggleTagFilter("filterInfo", "I"));
        self.options.getOption("filterDebug").on("change", self.toggleTagFilter("filterDebug", "D"));
        self.options.getOption("filterVerbose").on("change", self.toggleTagFilter("filterVerbose", "V"));

        // Create the w2ui layout.
        self.$el.w2layout({
            name: "ps_layout",
            padding: 4,
            panels: [
                {
                    type: "top",
                    size: 50,
                    toolbar: {
                        items: [
                            { type: "check", id: "btnPause", icon: "icon-pause",
                                checked: self.options.getOptionValue("paused")
                            },
                            { type: "break" },
                            { type: "html", html: "<span style='margin-left: 1em'>Process delay:</span>" },
                            { type: "menu",  id: "mnuDelay", caption: "", img: "icon-time", items: [
                                { id: "1000", text: "1 sec" },
                                { id: "2000", text: "2 sec" },
                                { id: "5000", text: "5 sec" },
                                { id: "10000", text: "10 sec" }
                            ]},
                            { type: "break" },
                            { type: "html", html: "<span style='margin-left: 1em'>Graph delay:</span>" },
                            { type: "menu",  id: "mnuGraphDelay", caption: "", img: "icon-time", items: [
                                { id: "500", text: "500 msec"},
                                { id: "1000", text: "1 sec" },
                                { id: "2000", text: "2 sec" },
                                { id: "5000", text: "5 sec" },
                                { id: "10000", text: "10 sec" }
                            ]},
                            { type: "break" },
                            { type: "html", html: "<span id='txtSortType' style='margin-left: 1em'>No sorting</span>" },
                            { type: "button", id: "btnCancelSort", caption: "Cancel", disabled: true },
                            { type: "spacer" },
                            { type: "html", html: "<div id='cpuGraph'></div>" },
                            { type: "html", html: "<div id='memGraph'></div>" },
                            { type: "html", html:
                                "<a href='http://www.opersys.com'><img alt='opersys logo' src='/images/opersys_land_logo.png' /></a>" },
                            { type: "html", html:
                                "<a href='javascript:showApropos()'><img alt='copyright icon' src='/images/copyright.png' /></a>" }
                        ],
                        onClick: function (ev) {
                            if (ev.target == "btnPause")
                                self.options.toggleOption("paused");

                            if (ev.target == "btnCancelSort") {
                                self.procView.treeSort();
                                $("#txtSortType").text("No sorting");
                                w2ui["ps_layout"].get("top").toolbar.disable("btnCancelSort");
                            }

                            if (ev.target.match(/mnuDelay*/) && ev.subItem)
                                self.options.setOptionValue("delay", ev.subItem.id);

                            if (ev.target.match(/mnuGraphDelay*/) && ev.subItem)
                                self.options.setOptionValue("graphDelay", ev.subItem.id);
                        }
                    }
                },
                {
                    type: "preview",
                    size: 200,
                    resizer: 5,
                    resizable: true,
                    toolbar: {
                        name: "tbPreview",
                        items: [
                            { type: "check",  id: "btnFilterByProcess", caption: "Filter", icon: "icon-long-arrow-down",
                                checked: self.options.getOptionValue("pidFilterMode")
                            },
                            { type: "button", id: "btnClear", caption: "Clear",  icon: "icon-remove" },
                            { type: "check",  id: "btnColors", caption: "Color",  icon: "icon-tint",
                                checked: self.options.getOptionValue("rowColorMode")
                            },
                            { type: "button", id: "btnEnd", caption: "", icon: "icon-double-angle-down" },
                            { type: "break" },
                            { type: "check", id: "btnFilterError", caption: "E",
                                checked: self.options.getOptionValue("filterError") },
                            { type: "check", id: "btnFilterWarning", caption: "W",
                                checked: self.options.getOptionValue("filterWarning") },
                            { type: "check", id: "btnFilterInfo", caption: "I",
                                checked: self.options.getOptionValue("filterInfo") },
                            { type: "check", id: "btnFilterDebug", caption: "D",
                                checked: self.options.getOptionValue("filterDebug") },
                            { type: "check", id: "btnFilterVerbose", caption: "V",
                                checked: self.options.getOptionValue("filterVerbose") },
                            { type: "break" },
                            { type: "html",   id: "txtFiltered", html: "<div id='txtFiltered'></div>" },
                            { type: "spacer" },
                            { type: "button", id: "btnMinimize", icon: "icon-chevron-down" }
                        ],
                        onClick: function (ev) {
                            if (ev.target == "btnClear")
                                self.logCatLines.clearAll();

                            if (ev.target == "btnFilterByProcess")
                                self.options.toggleOption("pidFilterMode");

                            if (ev.target == "btnColors")
                                self.options.toggleOption("rowColorMode");

                            if (ev.target == "btnMinimize")
                                self.options.toggleOption("minimizeLogcat");

                            if (ev.target == "btnEnd")
                                self.logCatView.scrollToEnd();

                            if (ev.target == "btnFilterError")
                                self.options.toggleOption("filterError");

                            if (ev.target == "btnFilterWarning")
                                self.options.toggleOption("filterWarning");

                            if (ev.target == "btnFilterInfo")
                                self.options.toggleOption("filterInfo");

                            if (ev.target == "btnFilterDebug")
                                self.options.toggleOption("filterDebug");

                            if (ev.target == "btnFilterVerbose")
                                selfoptions.toggleOption("filterVerbose");
                        }
                    }
                },
                {
                    type: "right",
                    size: 40,
                    resizer: 5,
                    resizable: true,
                    style: "opacity: 0.92;",
                }
            ],
            onResize: function (ev) {
                var main_panel = $(this.el("main").parentElement);

                ev.onComplete = function () {
                    // Avoid resizing the main panel so that we can have an
                    // overlay panel on the right. Keep 40px for the scrollbar.
                    main_panel.width($(window).width() - 40);

                    if (self.procView)
                        self.procView.autoResize();
                    if (self.logCatView)
                        self.logCatView.autoResize();
                };
            }
        });

        self.cpuChart = new ChartView({
            el: $("#cpuGraph"),
            max: 100,
            min: 0,
            delay: self.options.getOptionValue("graphDelay"),
            width: 200,
            height: 50
        });
        self.memChart = new ChartView({
            el: $("#memGraph"),
            min: 0,
            delay: self.options.getOptionValue("graphDelay"),
            width: 200,
            height:50
        });
        // Process details view
        self.procDetailsView = new ProcessDetailsView({
            el: $(w2ui["ps_layout"].el("right")),
            options: self.options
        });
        self.procView = new ProcessView({
            el: $(w2ui["ps_layout"].el("main")).addClass("processview"),
            ps: self.ps,
            options: self.options
        });
        self.logCatView = new LogCatView({
            el: $(w2ui["ps_layout"].el("preview")).addClass("logcatview"),
            logcat: self.logCatLines,
            ps: self.ps,
            options: self.options
        });

        self.procView.on("sort", function (sortField, sortFieldText) {
            $("#txtSortType").text("Sorting by: " + sortFieldText);
            w2ui["ps_layout"].get("top").toolbar.enable("btnCancelSort");
        });

        self.procView.on("onProcessSelected", function (el) {
            if (self.options.getOptionValue("pidFilterMode"))
                self.logCatView.filterByPid(el.get("pid"));

            self.logCatView.readLogsHeuristicCheck();

            self.procDetailsView.setProcess(el);
            self.procDetailsView.refresh();
        });

        self.procView.on("onContextMenuDetailsClick", function () {
            self.procDetailsView.toggle();
        });

        // Initialize the timer.
        self.updateTimer = $.timer(
            function () {
                self.globalProcessUpdate(self);
            },
            self.options.getOptionValue("delay"));
        self.graphUpdateTimer = $.timer(
            function () {
                self.graphUpdate(self);
            },
            self.options.getOptionValue("graphDelay"));

        self.options.getOption("paused").on("change", function () {
            var v = self.options.getOptionValue("paused");

            if (!v) {
                self.updateTimer.play();
                self.graphUpdateTimer.play();

                if (self.cpuChart) self.cpuChart.start();
                if (self.memChart) self.memChart.start();
            }
            else {
                self.updateTimer.pause();
                self.graphUpdateTimer.pause();

                if (self.cpuChart) self.cpuChart.stop();
                if (self.memChart) self.memChart.stop();
            }
        });

        self.options.getOption("delay").on("change", function () {
            var v = self.options.getOptionValue("delay");

            self.updateTimer.set({ time: v });

            // Update the toolbar text.
            self.setButton(w2ui["ps_layout"].get("top").toolbar, "mnuDelay", {
                caption: (v / 1000) + "s"
            });

            w2ui["ps_layout"].get("top").toolbar.refresh("mnuDelay");
        });

        self.options.getOption("graphDelay").on("change", function () {
            var v = self.options.getOptionValue("graphDelay");

            self.graphUpdateTimer.set({ time: v });

            self.cpuChart.resetDelay(v);
            self.memChart.resetDelay(v);

            // Update the toolbar text.
            self.setButton(w2ui["ps_layout"].get("top").toolbar, "mnuGraphDelay", {
                caption: (v / 1000) + "s"
            });

            w2ui["ps_layout"].get("top").toolbar.refresh("mnuGraphDelay");
        });

        self.options.getOption("minimizeLogcat").on("change", function () {
            var buttonsToHide = [
                "btnFilterByProcess", "btnClear", "btnColors", "btnEnd",
                "btnFilterError", "btnFilterWarning", "btnFilterInfo", "btnFilterDebug",
                "btnFilterVerbose"
            ];

            var panel = w2ui["ps_layout"].get("preview");

            if (self.options.getOptionValue("minimizeLogcat")) {
                _.each(buttonsToHide, function (btn) {
                    self.setButton(panel.toolbar, btn, {hidden: true});
                });
                self.setButton(panel.toolbar, "btnMinimize", {icon: "icon-chevron-up"});

                w2ui["ps_layout"].set("preview", {size: 0});
            } else {
                _.each(buttonsToHide, function (btn) {
                    self.setButton(panel.toolbar, btn, {hidden: false});
                });
                self.setButton(panel.toolbar, "btnMinimize", {icon: "icon-chevron-down"});

                w2ui["ps_layout"].set("preview", {size: 200});
            }

            panel.toolbar.refresh();
            self.logCatView.setElement(w2ui["ps_layout"].el("preview"));
            self.logCatView.render();
        });

        self.options.getOption("pidFilterMode").on("change", function () {
            if (!self.options.getOptionValue("pidFilterMode"))
                self.logCatView.clearPidFilter();
            else {
                if (self.procView.getSelectedProcess())
                    self.logCatView.filterByPid(self.procView.getSelectedProcess().get("pid"));
            }
        });
    },

    activate: function () {
        var self = this;

        // Update the process list right now.
        self.globalProcessUpdate(self);

        // Start the timers.
        self.updateTimer.play();
        self.graphUpdateTimer.play();
    },

    deactivate: function () {
        var self = this;

        self.updateTimer.pause();
        self.graphUpdateTimer.pause();
    },

    resize: function (width, height) {
        var self = this;

        self.$el
            .width(width)
            .height(height);

        w2ui["ps_layout"].resize();
        self.procView.autoResize();
    }
});


/* ******** */

//####assets/js/pstree.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var fs = new FileSystem();

var resizeWindow = function () {
/*    $("#psLayout")
        .width($(window).width())
        .height($(window).height());
    w2ui["psLayout"].resize();*/
};

function uncompress(clist) {
    var ctab = clist.ctab;
    var lstlst = clist.list;
    var r = [];

    _.each(lstlst, function (lst) {
        var obj = {};

        _.each(ctab, function (k) {
            obj[k] = lst.shift();
        });
        r.push(obj);
    });
    return r;
}

function showApropos() {
    w2popup.load({
        width: "640",
        height: "480",
        url: "/apropos"
    });
}

/* ******** */

//####assets/js/app.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Applications entry point.

var resizeWindow = function () {
    var tabsContainer;

    tabsContainer = $("#tabsContainer");

    tabsContainer
        .width($(window).width())
        .height($(window).height());

    // Change the size of the target div.
    if (Applications[w2ui["tabs"].active] && Applications[w2ui["tabs"].active].object != null)
        Applications[w2ui["tabs"].active].object.resize(
            tabsContainer.width(),
            tabsContainer.height() - $("#tabs").height());
};

var Applications = {};

var createTabApp = function (caption, optionObj, createObjectFun) {
    var tabContainer, tabDiv, tabId = _.uniqueId("tab");

    tabContainer = $("#tabsContainer");
    tabDiv = $("<div></div>")
        .attr("id", tabId)
        .attr("class", "tab");
    tabContainer.append(tabDiv);

    w2ui["tabs"].add({
        id: tabId,
        caption: caption
    });

    Applications[tabId] = {
        activate: function () {
            return createObjectFun(tabDiv, optionObj)
        },
        object: null
    };
};

var activateApp = function (tabId) {
    var tabContainer;

    tabContainer = $("#tabsContainer");

    w2ui["tabs"].select(tabId);

    // Hide all the other tabs.
    $('#tabsContainer .tab').hide();

    // Deactivate the other tab.
    if (tabId != w2ui["tabs"].active)
        Applications[tabId].deactivate();

    // Show the tab div immediately.
    $("#tabsContainer #" + tabId).show();

    // Create the view object if it's not already created.
    if (!Applications[tabId].object)
        Applications[tabId].object = Applications[tabId].activate();

    // Activate and properly size the tab content.
    Applications[tabId].object.activate();
    Applications[tabId].object.resize(
        tabContainer.width(),
        tabContainer.height() - $("#tabs").height());
};

$(document).ready(function () {
    var options = new Options();

    Opentip.lastZIndex = 1000;
    Opentip.styles.warnPopup = {
        extends: "dark",
        hideTriggers: ["closeButton"]
    };

    options.fetch();
    options.initOption("pidFilterMode", false);
    options.initOption("rowColorMode", false);
    options.initOption("paused", false);
    options.initOption("delay", 5000);
    options.initOption("graphDelay", 2000);
    options.initOption("maximizeLogcat", false);
    options.initOption("minimizeLogcat", false);
    options.initOption("filterError", true);
    options.initOption("filterWarning", true);
    options.initOption("filterInfo", true);
    options.initOption("filterDebug", true);
    options.initOption("filterVerbose", true);

    $("#tabs").w2tabs({
        name: "tabs",
        onClick: function (event) {
            activateApp(event.target);
        },
        style: "display: hidden"
    });

    createTabApp("Processes", options, function (targetObj, optObj) {
        return new ProcessTab({
            target: targetObj,
            options: optObj
        });
    });

    $(window).resize($.debounce(100, resizeWindow));

    // Reformat the window content.
    resizeWindow();

    // Activate and resize the first application.
    firstTab = w2ui["tabs"].tabs[0].id;
    activateApp(firstTab);

    options.activate();
});
